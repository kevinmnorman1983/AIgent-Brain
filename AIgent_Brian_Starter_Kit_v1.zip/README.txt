
AIgent Brian Starter Kit v1
===========================

This package contains starter assets for AIgent Central and Brian:
- Docs: charters, rules, architecture, runbook, security mapping, checklist.
- Repos: entity vaults, entity center, public site, ops automation.
- Teams extension: manifest and command stubs.
- Copilot Studio: action specs.
- Power Automate: adaptive card and flow blueprints.

All files are US-ASCII. Customize and deploy per the included instructions.
