
import { AzureFunction, Context, HttpRequest } from "@azure/functions";
import * as crypto from "crypto";

const httpTrigger: AzureFunction = async function (context: Context, req: HttpRequest) {
  const sig = req.headers["x-aigent-signature"] || "";
  const body = req.rawBody || "";
  const secret = process.env.WEBHOOK_SECRET || "";
  const hmac = crypto.createHmac("sha256", secret).update(body).digest("hex");

  if (sig !== `sha256=${hmac}`) {
    context.res = { status: 401, body: "invalid signature" };
    return;
  }

  const payload = req.body || {};
  // TODO:
  // 1) Save files to SharePoint staging or GitHub staging branch
  // 2) Open PR with auto summary; label with 'from-webhook'

  context.res = { status: 200, body: { ok: true } };
};

export default httpTrigger;
