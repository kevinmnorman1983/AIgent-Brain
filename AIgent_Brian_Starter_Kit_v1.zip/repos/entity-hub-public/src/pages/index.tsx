
import Link from "next/link";

export default function Home() {
  return (
    <main style={{maxWidth:880,margin:"40px auto",fontFamily:"system-ui"}}>
      <h1>AIgent Entity Hub</h1>
      <p>Curated, approved releases across entities.</p>
      <ul>
        <li><Link href="/releases">Releases</Link></li>
        <li><Link href="/about">About</Link></li>
      </ul>
    </main>
  );
}
