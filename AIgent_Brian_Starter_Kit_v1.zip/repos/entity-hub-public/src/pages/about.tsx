
export default function About() {
  return (
    <main style={{maxWidth:880,margin:"40px auto"}}>
      <h1>About</h1>
      <p>This is the public site for AIgent curated releases.</p>
    </main>
  );
}
