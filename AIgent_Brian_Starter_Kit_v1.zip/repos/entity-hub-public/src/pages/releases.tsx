
export default function Releases() {
  return (
    <main style={{maxWidth:880,margin:"40px auto"}}>
      <h1>Releases</h1>
      <p>Latest public-approved artifacts.</p>
    </main>
  );
}
