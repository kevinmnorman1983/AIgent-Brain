
# Entity Hub Public (Vercel)

Deploy steps:
- Create new project in Vercel, link to this repo.
- On merge to main, Vercel builds static site and serves.
- Artifacts published by pipeline land in /public/releases/ and are indexed into /public/releases/index.json.

Local:
- npm i
- npm run dev
