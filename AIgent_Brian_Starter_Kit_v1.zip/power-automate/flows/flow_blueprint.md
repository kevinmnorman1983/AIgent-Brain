
Content Change Approval Flow (Blueprint)
---------------------------------------
Trigger: HTTP (from Copilot Action GitHub_OpenPR) or GitHub webhook
1) Build Adaptive Card with PR metadata, diffs, risks.
2) Post to Teams (Kevin) with Approve/Reject.
3) If Approve -> call GitHub API: Merge PR.
4) If Reject  -> comment with reason, close PR.
5) Log outcome to SharePoint Approvals list.

Public Release Approval Flow (Blueprint)
----------------------------------------
Trigger: PR labeled release-candidate
1) Request Vercel preview build (via GitHub Action or API).
2) Post preview URL in Teams Adaptive Card.
3) Approve -> merge PR; Promote artifacts to public repo.
4) Reject -> remove label; post feedback.
