
export async function handleUpload(context, params) {
  // TODO: call Azure Function ingest endpoint with signed token
  return { text: "Staged upload. PR link will appear here." };
}

export async function handleRequestSummary(context, params) {
  // TODO: call Copilot Studio Action: Summary_Generate
  return { text: "Draft summary created. Review PR." };
}

export async function handlePublishUpdate(context, params) {
  // TODO: open Release PR and request Vercel preview
  return { text: "Release PR opened. Preview pending." };
}
