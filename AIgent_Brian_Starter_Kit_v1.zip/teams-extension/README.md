
AIgent Central Teams Extension
==============================

- Update manifest/manifest.json with your Bot App ID and domains.
- Implement handlers in src/commands.ts.
- Package and upload to Teams admin center for testing.
